package com.csmtech.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.csmtech.entity.TableHospital;

@Repository
public interface HospitalRepository extends JpaRepository<TableHospital, Integer > {
	
	@Query(value="Select TD.doctor_name,TP.patient_name,TIS.insurance_scheme_name,TI.insurance_name,TPD.addmission_date,TPD.discharge_date,TPD.insured_amount,TPD.total_expenses,TPD.total_payble_amount FROM  table_patient TP\r\n"
			+ "inner join  table_insurance_scheme TIS on TIS.isurance_scheme_id=TP.isurance_scheme_id\r\n"
			+ "inner join table_insurance TI on TI.insurance_id=TIS.insurance_id\r\n"
			+ "inner join table_doctor TD on TD.doctor_id=TP.doctor_id\r\n"
			+ "inner join table_hospital TH on TH.hospital_id=TD.hospital_id\r\n"
			+ "inner join table_patient_details TPD on TPD.patient_id=TP.patient_id\r\n"
			+ "where TH.hospital_id=:hospitalId", nativeQuery=true)
	List<Object[]> getTableDetailsByHospitalId(Integer hospitalId);

}
